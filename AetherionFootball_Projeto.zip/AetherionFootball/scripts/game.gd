extends Node3D

const FIELD_LENGTH := 34.0
const FIELD_WIDTH := 22.0
const PLAYER_SPEED := 7.0
const BALL_KICK_SPEED := 13.0

var player: CharacterBody3D
var ball: RigidBody3D
var opponents: Array[CharacterBody3D] = []
var teammates: Array[CharacterBody3D] = []
var move_dir := Vector2.ZERO
var sprinting := false
var score_blue := 0
var score_red := 0
var score_label: Label
var message_label: Label
var joystick_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_current := Vector2.ZERO

func _ready() -> void:
    _build_world()
    _build_hud()
    _reset_positions()

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    environment.sky.sky_material = ProceduralSkyMaterial.new()
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.72, 0.78, 0.88)
    environment.ambient_light_energy = 0.8
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -25, 0)
    sun.light_energy = 1.25
    add_child(sun)

    _make_box("Campo", Vector3(0, -0.25, 0), Vector3(FIELD_WIDTH, 0.5, FIELD_LENGTH), Color(0.22, 0.68, 0.18))
    for i in range(8):
        var z := -FIELD_LENGTH / 2.0 + (i + 0.5) * FIELD_LENGTH / 8.0
        var stripe_color := Color(0.28, 0.74, 0.22) if i % 2 == 0 else Color(0.22, 0.66, 0.17)
        _make_box("Faixa", Vector3(0, 0.012, z), Vector3(FIELD_WIDTH, 0.025, FIELD_LENGTH / 8.0), stripe_color, false)

    # Linhas simples do campo
    _make_box("Linha lateral esquerda", Vector3(-FIELD_WIDTH/2, 0.04, 0), Vector3(0.12, 0.05, FIELD_LENGTH), Color.WHITE, false)
    _make_box("Linha lateral direita", Vector3(FIELD_WIDTH/2, 0.04, 0), Vector3(0.12, 0.05, FIELD_LENGTH), Color.WHITE, false)
    _make_box("Linha fundo norte", Vector3(0, 0.04, -FIELD_LENGTH/2), Vector3(FIELD_WIDTH, 0.05, 0.12), Color.WHITE, false)
    _make_box("Linha fundo sul", Vector3(0, 0.04, FIELD_LENGTH/2), Vector3(FIELD_WIDTH, 0.05, 0.12), Color.WHITE, false)
    _make_box("Linha meio", Vector3(0, 0.045, 0), Vector3(FIELD_WIDTH, 0.045, 0.12), Color.WHITE, false)
    _make_ring()

    _make_goal(-FIELD_LENGTH/2, Color(0.95, 0.18, 0.18))
    _make_goal(FIELD_LENGTH/2, Color(0.15, 0.35, 1.0))

    player = _make_player("Você", Vector3(0, 0.1, 5.5), Color(0.2, 0.3, 1.0))
    for p in [Vector3(-5,0.1,7), Vector3(5,0.1,7)]:
        teammates.append(_make_player("Aliado", p, Color(0.18, 0.32, 1.0)))
    for p in [Vector3(-5,0.1,-6), Vector3(0,0.1,-8), Vector3(5,0.1,-6)]:
        opponents.append(_make_player("Adversário", p, Color(0.95, 0.18, 0.18)))

    ball = RigidBody3D.new()
    ball.name = "Bola"
    ball.mass = 0.45
    ball.position = Vector3(0, 0.55, 3.7)
    ball.linear_damp = 0.8
    ball.angular_damp = 0.7
    var sphere := SphereMesh.new()
    sphere.radius = 0.42
    sphere.height = 0.84
    var ball_mesh := MeshInstance3D.new()
    ball_mesh.mesh = sphere
    var ball_mat := StandardMaterial3D.new()
    ball_mat.albedo_color = Color(0.97, 0.97, 0.94)
    ball_mat.roughness = 0.6
    ball_mesh.material_override = ball_mat
    ball.add_child(ball_mesh)
    var ball_shape := CollisionShape3D.new()
    var sphere_shape := SphereShape3D.new()
    sphere_shape.radius = 0.42
    ball_shape.shape = sphere_shape
    ball.add_child(ball_shape)
    add_child(ball)

    var camera := Camera3D.new()
    camera.name = "Camera3D"
    camera.position = Vector3(0, 17, 23)
    camera.rotation_degrees = Vector3(-34, 0, 0)
    camera.current = true
    add_child(camera)

func _make_box(n: String, pos: Vector3, size: Vector3, color: Color, collision := true) -> void:
    var body: StaticBody3D
    if collision:
        body = StaticBody3D.new()
    else:
        body = StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.9
    mesh.material_override = mat
    body.add_child(mesh)
    if collision:
        var shape := CollisionShape3D.new()
        var box_shape := BoxShape3D.new()
        box_shape.size = size
        shape.shape = box_shape
        body.add_child(shape)
    add_child(body)

func _make_ring() -> void:
    var torus := TorusMesh.new()
    torus.inner_radius = 4.0
    torus.outer_radius = 4.08
    var mesh := MeshInstance3D.new()
    mesh.mesh = torus
    mesh.position = Vector3(0, 0.06, 0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    mesh.material_override = mat
    add_child(mesh)

func _make_goal(z: float, color: Color) -> void:
    var goal := Node3D.new()
    goal.position = Vector3(0, 0, z)
    add_child(goal)
    for x in [-3.0, 3.0]:
        _make_goal_post(goal, Vector3(x, 1.5, 0), Vector3(0.18, 3.0, 0.18), color)
    _make_goal_post(goal, Vector3(0, 3.0, 0), Vector3(6.0, 0.18, 0.18), color)
    _make_goal_post(goal, Vector3(-3, 1.5, -1.2), Vector3(0.12, 3.0, 2.4), Color(0.8,0.85,0.9))
    _make_goal_post(goal, Vector3(3, 1.5, -1.2), Vector3(0.12, 3.0, 2.4), Color(0.8,0.85,0.9))

func _make_goal_post(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> void:
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mesh.material_override = mat
    parent.add_child(mesh)

func _make_player(n: String, pos: Vector3, color: Color) -> CharacterBody3D:
    var p := CharacterBody3D.new()
    p.name = n
    p.position = pos
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.7
    var body_mesh := MeshInstance3D.new()
    body_mesh.mesh = capsule
    body_mesh.position.y = 0.85
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.75
    body_mesh.material_override = mat
    p.add_child(body_mesh)

    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.32
    head_mesh.height = 0.64
    head.mesh = head_mesh
    head.position.y = 1.9
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.82, 0.62, 0.46)
    head.material_override = skin
    p.add_child(head)

    var shape := CollisionShape3D.new()
    var cap_shape := CapsuleShape3D.new()
    cap_shape.radius = 0.45
    cap_shape.height = 1.8
    shape.shape = cap_shape
    shape.position.y = 0.9
    p.add_child(shape)
    add_child(p)
    return p

func _build_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(18, 14)
    panel.custom_minimum_size = Vector2(210, 62)
    layer.add_child(panel)
    var vbox := VBoxContainer.new()
    panel.add_child(vbox)
    score_label = Label.new()
    score_label.text = "AZUL  0  -  0  VERMELHO"
    score_label.add_theme_font_size_override("font_size", 22)
    vbox.add_child(score_label)
    message_label = Label.new()
    message_label.text = "Partida local • 3 contra 3"
    vbox.add_child(message_label)

    _add_button(layer, "↑", Vector2(92, 480), Vector2(70, 62), "up")
    _add_button(layer, "↓", Vector2(92, 610), Vector2(70, 62), "down")
    _add_button(layer, "←", Vector2(18, 545), Vector2(70, 62), "left")
    _add_button(layer, "→", Vector2(166, 545), Vector2(70, 62), "right")
    _add_button(layer, "CORRER", Vector2(255, 590), Vector2(120, 60), "sprint")
    _add_button(layer, "CHUTAR", Vector2(1080, 560), Vector2(150, 78), "shoot")
    _add_button(layer, "PASSE", Vector2(920, 610), Vector2(130, 65), "pass")

func _add_button(layer: CanvasLayer, label_text: String, pos: Vector2, size: Vector2, action: String) -> void:
    var b := Button.new()
    b.text = label_text
    b.position = pos
    b.size = size
    b.add_theme_font_size_override("font_size", 20)
    b.modulate = Color(1, 1, 1, 0.92)
    layer.add_child(b)
    if action in ["up", "down", "left", "right", "sprint"]:
        b.button_down.connect(func(): _set_action(action, true))
        b.button_up.connect(func(): _set_action(action, false))
    elif action == "shoot":
        b.pressed.connect(_shoot)
    elif action == "pass":
        b.pressed.connect(_pass_ball)

func _set_action(action: String, pressed: bool) -> void:
    match action:
        "up": move_dir.y = -1.0 if pressed else (0.0 if move_dir.y < 0 else move_dir.y)
        "down": move_dir.y = 1.0 if pressed else (0.0 if move_dir.y > 0 else move_dir.y)
        "left": move_dir.x = -1.0 if pressed else (0.0 if move_dir.x < 0 else move_dir.x)
        "right": move_dir.x = 1.0 if pressed else (0.0 if move_dir.x > 0 else move_dir.x)
        "sprint": sprinting = pressed

func _physics_process(delta: float) -> void:
    var keyboard := Vector2(
        Input.get_action_strength("ui_right") - Input.get_action_strength("ui_left"),
        Input.get_action_strength("ui_down") - Input.get_action_strength("ui_up")
    )
    var direction := move_dir
    if keyboard.length() > 0.1:
        direction = keyboard
    direction = direction.normalized()
    player.velocity.x = direction.x * PLAYER_SPEED * (1.45 if sprinting else 1.0)
    player.velocity.z = direction.y * PLAYER_SPEED * (1.45 if sprinting else 1.0)
    player.velocity.y -= 20.0 * delta
    player.move_and_slide()
    player.position.x = clamp(player.position.x, -FIELD_WIDTH/2 + 1, FIELD_WIDTH/2 - 1)
    player.position.z = clamp(player.position.z, -FIELD_LENGTH/2 + 1, FIELD_LENGTH/2 - 1)

    # Adversários seguem a bola de forma simples
    for enemy in opponents:
        var target := ball.global_position
        var to_ball := Vector3(target.x - enemy.global_position.x, 0, target.z - enemy.global_position.z)
        if to_ball.length() > 1.5:
            enemy.velocity.x = to_ball.normalized().x * 3.2
            enemy.velocity.z = to_ball.normalized().z * 3.2
        else:
            enemy.velocity.x = 0
            enemy.velocity.z = 0
        enemy.velocity.y -= 20.0 * delta
        enemy.move_and_slide()

    # Limites laterais aproximados
    if abs(ball.position.x) > FIELD_WIDTH/2:
        ball.linear_velocity.x *= -0.7
        ball.position.x = clamp(ball.position.x, -FIELD_WIDTH/2, FIELD_WIDTH/2)
    if ball.position.z < -FIELD_LENGTH/2:
        score_blue += 1
        _goal_scored("Gol azul!")
    elif ball.position.z > FIELD_LENGTH/2:
        score_red += 1
        _goal_scored("Gol vermelho!")
    score_label.text = "AZUL  %d  -  %d  VERMELHO" % [score_blue, score_red]

func _shoot() -> void:
    if player.global_position.distance_to(ball.global_position) < 3.2:
        var dir := Vector3(0, 0.12, -1)
        dir.x = (ball.global_position.x - player.global_position.x) * 0.18
        ball.apply_central_impulse(dir.normalized() * BALL_KICK_SPEED)
        message_label.text = "Chute!"

func _pass_ball() -> void:
    if player.global_position.distance_to(ball.global_position) < 3.8:
        var target := Vector3(0, 0, -1)
        ball.apply_central_impulse(target * 6.5)
        message_label.text = "Passe!"

func _goal_scored(text_message: String) -> void:
    message_label.text = text_message
    ball.linear_velocity = Vector3.ZERO
    ball.angular_velocity = Vector3.ZERO
    ball.position = Vector3(0, 0.6, 0)
    player.position = Vector3(0, 0.1, 5.5)
